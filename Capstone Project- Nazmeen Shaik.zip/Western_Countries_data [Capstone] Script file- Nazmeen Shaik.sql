select * from finance.western_data;
/*Product wise sales analysis*/
select Product, sum(sales) as sales, sum(`units sold`) as Units_Sold, sum(profit) as profit from finance.western_data group by product order by sum(sales) desc;

/*Segment wise profit*/
select segment, sum(profit) as Profit_By_Segment from finance.western_data group by segment order by sum(profit) desc;

/*Yearly Sales and profit*/
select Year, sum(sales) as Sales, sum(profit) as Yearly_Profit from finance.western_data group by year order by Year;

/*Country wise sales*/
select country, sum(sales) as Sales from finance.western_data group by country order by sum(sales) desc;

/*Product wise discount*/
select Product, sum(discounts) as Discount_by_Product from finance.western_data group by product order by sum(discounts) desc;

/* Segment wise Product wise Profit*/
select Segment, Product, sum(profit) as Profit from finance.western_data group by segment,Product;

/*Top 2 countries by profit*/
WITH top_countries AS (
SELECT country, sum(profit) AS Profit, sum(sales) as Sales, sum(`units sold`) as Units_Sold FROM finance.western_Data  GROUP BY country order by sum(profit) desc)
select * from top_countries limit 2;

/*Bottom 3 Products by profit*/
WITH Bottom_products AS (
SELECT Product, sum(profit) as Profit, sum(sales) as Sales,sum(`units sold`) as `Units Sold` FROM finance.western_Data  GROUP BY Product order by sum(profit))
select * from Bottom_products limit 3;
